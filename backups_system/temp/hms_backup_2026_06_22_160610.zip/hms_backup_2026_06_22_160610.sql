-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: edl_hardwaremaintenancesystem
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `issue_updates`
--

DROP TABLE IF EXISTS `issue_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue_updates` (
  `update_id` int NOT NULL AUTO_INCREMENT,
  `issue_id` int NOT NULL,
  `technician_id` int NOT NULL,
  `status` enum('Pending','Assigned','In Progress','Waiting Parts','Resolved','Closed') NOT NULL,
  `solution_description` text,
  `recommendation` text,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`update_id`),
  KEY `fk_issue_updates_issue` (`issue_id`),
  KEY `fk_issue_updates_technician` (`technician_id`),
  CONSTRAINT `fk_issue_updates_issue` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_issue_updates_technician` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_updates`
--

LOCK TABLES `issue_updates` WRITE;
/*!40000 ALTER TABLE `issue_updates` DISABLE KEYS */;
INSERT INTO `issue_updates` VALUES (1,3,3,'Resolved',NULL,'Clean PC','2026-04-20 03:21:16'),(2,4,4,'Waiting Parts',NULL,'Required to replace Hard Disk','2026-04-20 03:34:33'),(3,2,4,'Waiting Parts',NULL,'Required to replace hard disk','2026-04-20 04:01:58'),(5,4,4,'Resolved',NULL,'Required to replace Hard Disk','2026-04-20 04:04:40'),(6,5,3,'Waiting Parts',NULL,'Required to replace battery','2026-04-20 04:20:15'),(7,5,3,'Resolved',NULL,'Required to replace battery','2026-04-20 04:22:01'),(8,6,4,'Waiting Parts',NULL,'','2026-04-20 05:41:36'),(10,6,4,'Resolved',NULL,'','2026-04-20 05:43:33'),(11,2,4,'Waiting Parts',NULL,'Required to replace hard disk','2026-04-20 05:58:28'),(12,2,4,'Waiting Parts',NULL,'Required to replace hard disk','2026-04-20 06:19:59'),(13,7,3,'Resolved',NULL,'Format pc','2026-04-20 06:48:38'),(14,8,3,'Resolved',NULL,'Format PC','2026-04-20 06:55:59'),(15,9,4,'Waiting Parts',NULL,'Replace Hard(SSD)','2026-04-20 06:57:29'),(16,9,4,'Resolved',NULL,'Replace Hard(SSD)','2026-04-20 07:03:31'),(17,12,3,'Resolved',NULL,'Installation Drivers','2026-04-20 07:22:18'),(18,13,3,'Waiting Parts',NULL,'Replace power supply','2026-04-20 07:33:16'),(19,14,4,'Waiting Parts',NULL,'Required to replace battery','2026-04-20 07:40:46'),(20,14,4,'Resolved',NULL,'Required to replace battery','2026-04-20 07:41:52'),(21,15,3,'Resolved',NULL,'Format PC','2026-04-20 07:44:19'),(22,13,3,'Resolved',NULL,'Replace power supply','2026-04-20 07:48:50'),(23,16,4,'Resolved',NULL,'Format PC','2026-04-20 07:55:57'),(24,16,4,'Resolved',NULL,'Format PC','2026-04-20 07:56:11'),(25,10,3,'Resolved',NULL,'','2026-04-21 18:27:59'),(26,20,3,'Resolved',NULL,'Installation (cheque printers and OS)','2026-04-28 05:30:30');
/*!40000 ALTER TABLE `issue_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issues` (
  `issue_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `issue_type` enum('Hardware','Software') NOT NULL,
  `issue_category` varchar(100) NOT NULL,
  `software_name` varchar(100) DEFAULT NULL,
  `issue_description` text NOT NULL,
  `service_tag` varchar(50) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `additional_information` text,
  `status` enum('Pending','Assigned','In Progress','Waiting Parts','Resolved','Closed') DEFAULT 'Pending',
  `technician_id` int DEFAULT NULL,
  `solution_description` text,
  `recommendation` text,
  `received_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `assigned_date` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_archived` tinyint(1) DEFAULT '0',
  `tech_archived` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`issue_id`),
  KEY `fk_issues_user` (`user_id`),
  KEY `fk_issues_technician` (`technician_id`),
  CONSTRAINT `fk_issues_technician` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_issues_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES (2,2,'Hardware','other',NULL,'Hard disk failure','HP',NULL,'','In Progress',4,NULL,'Required to replace hard disk','2026-04-10 10:25:50','2026-04-20 00:41:28',NULL,'2026-04-10 04:55:50','2026-04-20 06:20:42',0,0),(3,2,'Hardware','No power',NULL,'No power','HP',NULL,'','Resolved',3,NULL,'Clean PC','2026-04-20 08:50:22','2026-04-20 08:50:41','2026-04-20 08:51:16','2026-04-20 03:20:22','2026-04-20 03:21:16',0,0),(4,7,'Hardware','other',NULL,'Hard Disk Failure','HP',NULL,'','Resolved',4,NULL,'Required to replace Hard Disk','2026-04-20 08:54:35','2026-04-20 08:54:51','2026-04-20 09:34:40','2026-04-20 03:24:35','2026-04-20 04:04:40',0,0),(5,8,'Hardware','other',NULL,'Battery Dead','East - UPS',NULL,'','Resolved',3,NULL,'Required to replace battery','2026-04-20 09:40:42','2026-04-20 09:41:14','2026-04-20 09:52:01','2026-04-20 04:10:42','2026-04-20 04:22:01',0,0),(6,9,'Hardware','other',NULL,'Power supply','I3-Assemble Machine',NULL,'','Resolved',4,NULL,'','2026-04-20 09:58:00','2026-04-20 10:44:28','2026-04-20 11:13:33','2026-04-20 04:28:00','2026-04-20 05:43:33',0,0),(7,10,'Hardware','other',NULL,'05 error','e-wis',NULL,'','Resolved',3,NULL,'Format pc','2026-04-20 12:17:40','2026-04-20 12:18:06','2026-04-20 12:18:38','2026-04-20 06:47:40','2026-04-20 06:48:38',0,0),(8,10,'Hardware','other',NULL,'Hard disk error','Assembly PC',NULL,'','Resolved',3,NULL,'Format PC','2026-04-20 12:20:46','2026-04-20 12:25:09','2026-04-20 12:25:59','2026-04-20 06:50:46','2026-04-20 06:55:59',0,0),(9,11,'Hardware','other',NULL,'Hard disk error','Delux',NULL,'','Resolved',4,NULL,'Replace Hard(SSD)','2026-04-20 12:23:57','2026-04-20 12:25:06','2026-04-20 12:33:31','2026-04-20 06:53:57','2026-04-20 07:03:31',0,0),(10,12,'Hardware','Printer failure',NULL,'Printer failure','Dell-1H7DD25',NULL,'','Resolved',3,NULL,'','2026-04-20 12:44:33','2026-04-20 12:51:35','2026-04-21 23:57:59','2026-04-20 07:14:33','2026-04-21 18:27:59',0,0),(11,13,'Software','other',NULL,'OS Error','EGS i3, EGC/200/1600/0837',NULL,'','Assigned',4,NULL,NULL,'2026-04-20 12:48:40','2026-04-20 12:51:30',NULL,'2026-04-20 07:18:40','2026-04-20 07:21:30',0,0),(12,13,'Software','other',NULL,'Wireless Adapter Drivers','NEC',NULL,'','Resolved',3,NULL,'Installation Drivers','2026-04-20 12:49:32','2026-04-20 12:51:27','2026-04-20 12:52:18','2026-04-20 07:19:32','2026-04-20 07:22:18',0,0),(13,14,'Hardware','other',NULL,'Power supply error','Dell Vostro/2H7DD25',NULL,'','Resolved',3,NULL,'Replace power supply','2026-04-20 13:01:20','2026-04-20 13:02:26','2026-04-20 13:18:50','2026-04-20 07:31:20','2026-04-20 07:48:50',0,0),(14,15,'Hardware','other',NULL,'Battery Error','Computer power supply/310023332B76885700601',NULL,'','Resolved',4,NULL,'Required to replace battery','2026-04-20 13:06:41','2026-04-20 13:09:49','2026-04-20 13:11:52','2026-04-20 07:36:41','2026-04-20 07:41:52',0,0),(15,15,'Software','OS booting error',NULL,'OS booting error','Assembly PC',NULL,'','Resolved',3,NULL,'Format PC','2026-04-20 13:13:01','2026-04-20 13:13:44','2026-04-20 13:14:19','2026-04-20 07:43:01','2026-04-20 07:44:19',0,0),(16,10,'Software','other',NULL,'OS Error','Assembly PC, Delux',NULL,'','Resolved',4,NULL,'Format PC','2026-04-20 13:23:55','2026-04-20 13:24:20','2026-04-20 13:26:11','2026-04-20 07:53:55','2026-04-20 07:56:11',0,0),(17,13,'Hardware','other',NULL,'Motherboard Error','Dell',NULL,'','Assigned',3,NULL,NULL,'2026-04-22 08:46:45','2026-04-22 15:10:59',NULL,'2026-04-22 03:16:45','2026-04-22 09:40:59',0,0),(18,13,'Software','other',NULL,'OS Error','Dell',NULL,'','Assigned',3,NULL,NULL,'2026-04-22 08:48:04','2026-04-22 08:52:14',NULL,'2026-04-22 03:18:04','2026-04-22 03:22:14',0,0),(19,10,'Software','other',NULL,'OS error','Assembly PC','issue_69e9a8a5057778.63114504.png','','Assigned',3,NULL,NULL,'2026-04-23 10:35:41','2026-04-23 11:20:19',NULL,'2026-04-23 05:05:41','2026-04-23 05:50:19',0,0),(20,8,'Software','other',NULL,'OS Error','Dell Optiplex 5040 , S. No: HGC31H2',NULL,'','Resolved',3,NULL,'Installation (cheque printers and OS)','2026-04-28 10:55:54','2026-04-28 10:58:35','2026-04-28 11:00:30','2026-04-28 05:25:54','2026-04-28 05:30:30',0,0),(21,13,'Hardware','Restart',NULL,'Restart','Dell-Vostro03888, S.No: H2YP7J3',NULL,'','Assigned',18,NULL,NULL,'2026-04-30 09:01:15','2026-04-30 09:01:51',NULL,'2026-04-30 03:31:15','2026-04-30 03:31:51',0,0),(22,21,'Hardware','other',NULL,'Switch and casing','Acer, S.No:-4CE9111FNS',NULL,'','Assigned',18,NULL,NULL,'2026-05-06 12:16:06','2026-05-11 12:42:42',NULL,'2026-05-06 06:46:06','2026-05-11 07:12:42',0,0),(28,21,'Hardware','other',NULL,'Blue screen error','acer (i5-vertiou), s.no: 20100866992',NULL,'','Assigned',18,NULL,NULL,'2026-05-11 12:32:53','2026-05-11 12:50:51',NULL,'2026-05-11 07:02:53','2026-05-11 07:20:51',0,0),(29,23,'Hardware','other',NULL,'Power supply error','EGS, S.NO: EGS/200/1600/0601(PC)',NULL,'','Assigned',18,NULL,NULL,'2026-05-20 10:10:45','2026-06-02 13:51:40',NULL,'2026-05-20 04:40:45','2026-06-02 08:21:40',0,0),(30,23,'Hardware','other',NULL,'RAM Error(Beep Sound)','Assembly PC',NULL,'','Assigned',18,NULL,NULL,'2026-06-02 13:30:10','2026-06-02 13:51:37',NULL,'2026-06-02 08:00:10','2026-06-02 08:21:37',0,0),(31,24,'Software','other',NULL,'OS Error','Assembly PC',NULL,'','Assigned',18,NULL,NULL,'2026-06-02 13:34:45','2026-06-02 13:51:21',NULL,'2026-06-02 08:04:45','2026-06-02 08:21:21',0,0),(32,24,'Hardware','No power',NULL,'No power','Assembly PC',NULL,'','Assigned',18,NULL,NULL,'2026-06-02 13:36:07','2026-06-02 13:51:18',NULL,'2026-06-02 08:06:07','2026-06-02 08:21:18',0,0),(33,25,'Software','other',NULL,'OS Error and EDL system error','HP i5, serial no: 4CE549DR7M',NULL,'','Assigned',18,NULL,NULL,'2026-06-02 13:38:38','2026-06-02 13:51:15',NULL,'2026-06-02 08:08:38','2026-06-02 08:21:15',0,0),(34,25,'Software','other',NULL,'OS Updating Error and EDL System Error','HP i5, serial no: 4CE549BYC7',NULL,'','Assigned',18,NULL,NULL,'2026-06-02 13:40:15','2026-06-02 13:51:11',NULL,'2026-06-02 08:10:15','2026-06-02 08:21:11',0,0);
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `item_id` int NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) NOT NULL,
  `capacity_type` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `reorder_level` int NOT NULL DEFAULT '0',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `low_stock_threshold` int NOT NULL DEFAULT '5',
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'Pen Drive','128GB','PNY',3,0,0.00,'2026-04-07 07:38:58','2026-04-10 05:58:05',5),(5,'Monitor',NULL,NULL,3,0,15500.00,'2026-04-07 07:38:58','2026-05-07 03:54:47',5),(8,'External Hard Drive','1TB','Transcend',7,0,0.00,'2026-04-07 07:38:58','2026-04-10 06:00:26',5),(9,'Passthrough Crimping',NULL,NULL,1,0,5380.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(11,'Wireless Keyboard',NULL,NULL,3,0,2900.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(12,'Wireless Mouse',NULL,NULL,5,0,1400.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(13,'CD Albums (40 CDS)',NULL,NULL,2,0,2000.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(14,'USB Extension Cable','2m',NULL,5,0,480.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(15,'Printer Cable usb',NULL,NULL,10,0,350.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(16,'Printer Cable Parallel',NULL,NULL,5,0,850.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(17,'Patch Cable CAT 6','0.5m',NULL,100,0,295.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(18,'Patch Cable CAT 6','0.05m',NULL,20,0,595.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(19,'Patch Cable CAT 6','2m',NULL,100,0,395.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(20,'CAT6 Network Cable Box','610m',NULL,2,0,39500.00,'2026-04-07 07:38:58','2026-06-08 09:34:43',5),(21,'VGA Cables',NULL,NULL,10,0,550.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(23,'USB Keyboard',NULL,NULL,25,0,990.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(24,'PC casing with power supplyers',NULL,NULL,10,0,7450.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(28,'Heatsink Compound',NULL,NULL,1,0,750.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(29,'CMOS Battery',NULL,NULL,44,0,75.00,'2026-04-07 07:38:58','2026-06-08 09:35:21',5),(30,'Wireless Access Point','TL-WA1201','TP-LINK',2,0,16500.00,'2026-04-07 07:38:58','2026-04-07 07:38:58',5),(31,'HDMI Cable','1.5m',NULL,3,0,400.00,'2026-04-10 05:47:32','2026-04-10 05:47:32',5),(32,'Power Supply','550w','COLORSIT',10,0,4000.00,'2026-04-10 05:50:31','2026-04-10 05:50:31',5),(33,'CMOS Battery 2',NULL,NULL,20,0,80.00,'2026-04-10 05:53:50','2026-04-10 05:53:50',5),(34,'External Hard Drive','1TB','SEAGATE',1,0,0.00,'2026-04-10 06:01:59','2026-04-10 06:01:59',5),(35,'External Hard Drive','1TB','ADATA SSD',1,0,0.00,'2026-04-10 06:02:32','2026-04-10 06:02:32',5),(39,'Network Switch','8 Gigabit port',NULL,20,0,7500.00,'2026-04-10 06:27:58','2026-06-09 03:34:07',5),(40,'Network Switch','24 Gigabit port','Grandstream',4,0,26500.00,'2026-04-10 06:29:07','2026-06-09 03:32:54',5),(41,'External DVD Drive',NULL,NULL,1,0,0.00,'2026-04-10 06:47:48','2026-04-10 06:47:48',5),(42,'USB Printer Cable','5m',NULL,1,0,0.00,'2026-04-10 06:48:50','2026-04-10 06:48:50',5),(43,'USB Printer Cable','1.5m',NULL,5,0,410.00,'2026-04-10 06:49:52','2026-04-10 06:49:52',5),(44,'Sata Cable',NULL,NULL,15,0,150.00,'2026-04-10 06:51:01','2026-04-10 06:51:01',5),(45,'USB to RJ45 Connector',NULL,NULL,2,0,950.00,'2026-04-10 06:51:59','2026-04-10 06:51:59',5),(46,'USB to VGA Connector',NULL,NULL,4,0,1600.00,'2026-04-10 06:52:50','2026-04-10 06:52:50',5),(47,'USB Hub',NULL,NULL,2,0,990.00,'2026-04-10 06:53:24','2026-04-10 06:53:24',5),(48,'Wireless Adapter',NULL,NULL,6,0,1900.00,'2026-04-10 06:55:52','2026-04-10 06:55:52',5),(49,'Keyboard','Wired',NULL,8,0,1750.00,'2026-04-10 06:56:45','2026-06-08 09:46:16',5),(50,'Keyboard','Wireless',NULL,1,0,5750.00,'2026-04-10 06:57:24','2026-04-10 06:57:24',5),(51,'Thermal Paste','30g',NULL,3,0,300.00,'2026-04-10 06:59:24','2026-04-10 06:59:24',5),(52,'Power Cable',NULL,NULL,4,0,4500.00,'2026-04-10 07:00:27','2026-04-10 07:09:13',5),(53,'Network Switch','8 Port',NULL,1,0,3550.00,'2026-04-10 07:01:49','2026-04-10 07:01:49',5),(54,'Keystone',NULL,NULL,50,0,430.00,'2026-04-10 07:02:14','2026-04-10 07:02:14',5),(55,'Phase plate',NULL,NULL,5,0,300.00,'2026-04-10 07:02:37','2026-04-10 07:02:37',5),(56,'Contact Cleaner',NULL,NULL,1,0,820.00,'2026-04-10 07:03:09','2026-04-10 07:03:09',5),(57,'Cat 6 Network Cable','95m',NULL,1,0,58.69,'2026-04-10 07:08:30','2026-06-08 09:33:41',5),(58,'Hard Disk -SSD','512GB',NULL,1,0,9600.00,'2026-04-10 07:12:33','2026-06-08 09:45:35',5),(59,'Hard Disk',NULL,NULL,1,0,0.00,'2026-04-20 03:33:25','2026-04-27 09:38:38',5),(60,'Power Supply',NULL,NULL,1,0,0.00,'2026-04-20 05:40:01','2026-04-20 07:48:20',5),(61,'Motherboard',NULL,NULL,1,0,0.00,'2026-04-20 05:40:21','2026-04-20 06:35:31',5),(62,'Hard Disk -SSD',NULL,NULL,0,0,0.00,'2026-04-20 06:54:31','2026-04-20 07:02:56',5),(63,'Battery','7.5mAh',NULL,17,0,0.00,'2026-04-20 07:38:17','2026-06-08 09:33:07',5),(65,'Frame ATX Casing',NULL,NULL,10,5,7450.00,'2026-04-28 05:00:40','2026-06-09 03:42:59',5);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `notification_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_desktop_notified` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`notification_id`),
  KEY `fk_notification_user` (`user_id`),
  CONSTRAINT `fk_notification_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,1,'New Issue Reported','New issue submitted\nUser: DGM\nIssue ID: 1\nType: Hardware\nCategory: other\nService Tag: Dell\nStatus: Pending',1,'2026-04-10 10:25:06',0),(2,1,'New Issue Reported','New issue submitted\nUser: DGM\nIssue ID: 2\nType: Hardware\nCategory: other\nService Tag: HP\nStatus: Pending',1,'2026-04-10 10:25:50',0),(3,1,'New User Registration','New user registered to the system\nUsername: DM\nPhone: 0777777777\nRole: user',1,'2026-04-10 10:46:31',0),(5,4,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 2\nService Tag: HP\nDescription: Hard disk failure\nStatus: Assigned',1,'2026-04-20 00:41:28',0),(6,1,'New Issue Reported','New issue submitted\nUser: DGM\nIssue ID: 3\nType: Hardware\nCategory: No power\nService Tag: HP\nStatus: Pending',1,'2026-04-20 08:50:22',0),(7,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 3\nService Tag: HP\nDescription: No power\nStatus: Assigned',1,'2026-04-20 08:50:41',0),(8,1,'New Issue Reported','New issue submitted\nUser: DM\nIssue ID: 4\nType: Hardware\nCategory: other\nService Tag: HP\nStatus: Pending',1,'2026-04-20 08:54:35',0),(9,4,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 4\nService Tag: HP\nDescription: Hard Disk Failure\nStatus: Assigned',1,'2026-04-20 08:54:51',0),(10,1,'New Parts Request Submitted','A technician has requested parts.\nTechnician: technician2\nIssue ID: 4\nItem: Hard Disk\nQuantity: 1',1,'2026-04-20 09:04:33',0),(11,1,'Low Stock Warning','Inventory is running low.\nItem: Hard Disk\nRemaining Quantity: 0\nPlease restock soon.',1,'2026-04-20 09:05:31',0),(12,5,'Approved Item Request','Admin approved an item request.\nRequest ID: 1\nIssue ID: 4\nItem: Hard Disk\nApproved Quantity: 1\nAction: Please issue the item to the technician.',1,'2026-04-20 09:05:31',0),(13,1,'New Parts Request Submitted','A technician has requested parts.\nTechnician: technician2\nIssue ID: 2\nItem: Hard Disk\nQuantity: 1',1,'2026-04-20 09:31:58',0),(14,5,'Approved Item Request','Admin approved an item request.\nRequest ID: 2\nIssue ID: 2\nItem: Hard Disk\nApproved Quantity: 1\nAction: Please issue the item to the technician.',1,'2026-04-20 09:33:25',0),(15,1,'New User Registration','New user registered to the system\nUsername: ACC(Exp)\nPhone: 0777777772\nRole: user',1,'2026-04-20 09:36:09',0),(16,1,'New Issue Reported','New issue submitted\nUser: ACC(Exp)\nIssue ID: 5\nType: Hardware\nCategory: other\nService Tag: East - UPS\nStatus: Pending',1,'2026-04-20 09:40:42',0),(17,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 5\nService Tag: East - UPS\nDescription: Battery Dead\nStatus: Assigned',1,'2026-04-20 09:41:14',0),(18,1,'New Parts Request Submitted','A technician has requested parts.\nTechnician: technician1\nIssue ID: 5\nItem: UPS Battery\nQuantity: 1',1,'2026-04-20 09:50:15',0),(19,5,'Approved Item Request','Admin approved an item request.\nRequest ID: 3\nIssue ID: 5\nItem: UPS Battery\nApproved Quantity: 1\nAction: Please issue the item to the technician.',1,'2026-04-20 09:50:40',0),(20,1,'New User Registration','New user registered to the system\nUsername: Energy\nPhone: 0777777773\nRole: user',1,'2026-04-20 09:55:36',0),(21,1,'New Issue Reported','New issue submitted\nUser: Energy\nIssue ID: 6\nType: Hardware\nCategory: other\nService Tag: I3-Assemble Machine\nStatus: Pending',1,'2026-04-20 09:58:00',0),(22,4,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 6\nService Tag: I3-Assemble Machine\nDescription: Power supply\nStatus: Assigned',1,'2026-04-20 10:44:28',0),(23,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician2\nIssue ID: 6\nItems: Power Supply (Qty: 1), Motherboard (Qty: 1)',1,'2026-04-20 11:11:36',0),(24,5,'Approved Item Request','Admin approved an item request.\nRequest ID: 4\nIssue ID: 6\nItem: Power Supply\nApproved Quantity: 1\nAction: Please issue the item to the technician.',1,'2026-04-20 11:12:08',0),(25,1,'New User Registration','New user registered to the system\nUsername: kandycity\nPhone: 0777777776\nRole: user',1,'2026-04-20 11:16:18',0),(26,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician2\nIssue ID: 2\nItems: Motherboard (Qty: 1), Power Supply (Qty: 1)',1,'2026-04-20 11:28:28',0),(27,5,'Approved Item Request','Admin approved an item request.\nRequest ID: 5\nIssue ID: 2\nItem: Motherboard\nApproved Quantity: 1\nAction: Please issue the item to the technician.',1,'2026-04-20 11:28:52',0),(28,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician2\nIssue ID: 2\nItems: Power Supply (Qty: 1), Motherboard (Qty: 1)',1,'2026-04-20 11:49:59',0),(29,5,'Approved Spare Parts Request','Admin approved spare parts request.\nRequest ID: 6\nIssue ID: 2\nItems: Power Supply (Qty: 1), Motherboard (Qty: 1)\nAction: Please issue the items to the technician.',1,'2026-04-20 11:50:42',0),(30,4,'Spare Parts Issued','Storekeeper issued approved spare parts.\nRequest ID: 6\nIssue ID: 2\nItems: Power Supply (Qty: 1), Motherboard (Qty: 1)',1,'2026-04-20 11:51:03',0),(31,1,'New Issue Reported','New issue submitted\nUser: kandycity\nIssue ID: 7\nType: Hardware\nCategory: other\nService Tag: e-wis\nStatus: Pending',1,'2026-04-20 12:17:41',0),(32,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 7\nService Tag: e-wis\nDescription: 05 error\nStatus: Assigned',1,'2026-04-20 12:18:06',0),(33,1,'New Issue Reported','New issue submitted\nUser: kandycity\nIssue ID: 8\nType: Hardware\nCategory: other\nService Tag: Assembly PC\nStatus: Pending',1,'2026-04-20 12:20:46',0),(34,1,'New User Registration','New user registered to the system\nUsername: kandysouth\nPhone: 0777777778\nRole: user',1,'2026-04-20 12:22:28',0),(35,1,'New Issue Reported','New issue submitted\nUser: kandysouth\nIssue ID: 9\nType: Hardware\nCategory: other\nService Tag: Delux\nStatus: Pending',1,'2026-04-20 12:23:57',0),(36,4,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 9\nService Tag: Delux\nDescription: Hard disk error\nStatus: Assigned',1,'2026-04-20 12:25:06',0),(37,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 8\nService Tag: Assembly PC\nDescription: Hard disk error\nStatus: Assigned',1,'2026-04-20 12:25:09',0),(38,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician2\nIssue ID: 9\nItems: Hard Disk -SSD (Qty: 1)',1,'2026-04-20 12:27:29',0),(39,5,'Approved Spare Part Item','Admin approved one spare part item.\nRequest ID: 7\nIssue ID: 9\nItem: Hard Disk -SSD\nApproved Quantity: 1\nAction: Please issue this item.',1,'2026-04-20 12:27:52',0),(40,4,'Spare Part Issued','Storekeeper issued one approved spare part.\nRequest ID: 7\nIssue ID: 9\nItem: Hard Disk -SSD\nIssued Quantity: 1',1,'2026-04-20 12:32:56',0),(41,1,'New User Registration','New user registered to the system\nUsername: AO-Dambulla\nPhone: 0777777779\nRole: user',1,'2026-04-20 12:42:22',0),(42,1,'New Issue Reported','New issue submitted\nUser: AO-Dambulla\nIssue ID: 10\nType: Hardware\nCategory: Printer failure\nService Tag: Dell-1H7DD25\nStatus: Pending',1,'2026-04-20 12:44:33',0),(43,1,'New User Registration','New user registered to the system\nUsername: AO-Katugasthota\nPhone: 0777777701\nRole: user',1,'2026-04-20 12:46:29',0),(44,1,'New Issue Reported','New issue submitted\nUser: AO-Katugasthota\nIssue ID: 11\nType: Software\nCategory: other\nService Tag: EGS i3, EGC/200/1600/0837\nStatus: Pending',1,'2026-04-20 12:48:40',0),(45,1,'New Issue Reported','New issue submitted\nUser: AO-Katugasthota\nIssue ID: 12\nType: Software\nCategory: other\nService Tag: NEC\nStatus: Pending',1,'2026-04-20 12:49:32',0),(46,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 12\nService Tag: NEC\nDescription: Wireless Adapter Drivers\nStatus: Assigned',1,'2026-04-20 12:51:27',0),(47,4,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 11\nService Tag: EGS i3, EGC/200/1600/0837\nDescription: OS Error\nStatus: Assigned',0,'2026-04-20 12:51:30',0),(48,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 10\nService Tag: Dell-1H7DD25\nDescription: Printer failure\nStatus: Assigned',1,'2026-04-20 12:51:35',0),(49,1,'New User Registration','New user registered to the system\nUsername: CE(Cons)\nPhone: 0777777702\nRole: user',1,'2026-04-20 12:56:22',0),(50,1,'New Issue Reported','New issue submitted\nUser: CE(Cons)\nIssue ID: 13\nType: Hardware\nCategory: other\nService Tag: Dell Vostro/2H7DD25\nStatus: Pending',1,'2026-04-20 13:01:20',0),(51,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 13\nService Tag: Dell Vostro/2H7DD25\nDescription: Power supply error\nStatus: Assigned',1,'2026-04-20 13:02:26',0),(52,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician1\nIssue ID: 13\nItems: Power Supply (Qty: 1)',1,'2026-04-20 13:03:16',0),(53,5,'Approved Spare Part Item','Admin approved one spare part item.\nRequest ID: 8\nIssue ID: 13\nItem: Power Supply\nApproved Quantity: 1\nAction: Please issue this item.',1,'2026-04-20 13:03:40',0),(54,3,'Spare Part Issued','Storekeeper issued one approved spare part.\nRequest ID: 8\nIssue ID: 13\nItem: Power Supply\nIssued Quantity: 1',1,'2026-04-20 13:03:56',0),(55,1,'New User Registration','New user registered to the system\nUsername: Acc(Rev)\nPhone: 0777777703\nRole: user',1,'2026-04-20 13:05:05',0),(56,1,'New Issue Reported','New issue submitted\nUser: Acc(Rev)\nIssue ID: 14\nType: Hardware\nCategory: other\nService Tag: Computer power supply/310023332B76885700601\nStatus: Pending',1,'2026-04-20 13:06:41',0),(57,4,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 14\nService Tag: Computer power supply/310023332B76885700601\nDescription: Battery Error\nStatus: Assigned',0,'2026-04-20 13:09:49',0),(58,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician2\nIssue ID: 14\nItems: Battery (Qty: 2)',1,'2026-04-20 13:10:46',0),(59,5,'Approved Spare Part Item','Admin approved one spare part item.\nRequest ID: 9\nIssue ID: 14\nItem: Battery\nCapacity/Type: 7.5AW\nApproved Quantity: 2\nAction: Please issue this item.',1,'2026-04-20 13:11:09',0),(60,4,'Spare Part Issued','Storekeeper issued one approved spare part.\nRequest ID: 9\nIssue ID: 14\nItem: Battery\nCapacity/Type: 7.5AW\nIssued Quantity: 2',0,'2026-04-20 13:11:25',0),(61,1,'New Issue Reported','New issue submitted\nUser: Acc(Rev)\nIssue ID: 15\nType: Software\nCategory: OS booting error\nService Tag: Assembly PC\nStatus: Pending',1,'2026-04-20 13:13:01',0),(62,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 15\nService Tag: Assembly PC\nDescription: OS booting error\nStatus: Assigned',1,'2026-04-20 13:13:44',0),(63,1,'New Issue Reported','New issue submitted\nUser: kandycity\nIssue ID: 16\nType: Software\nCategory: other\nService Tag: Assembly PC, Delux\nStatus: Pending',1,'2026-04-20 13:23:55',0),(64,4,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 16\nService Tag: Assembly PC, Delux\nDescription: OS Error\nStatus: Assigned',0,'2026-04-20 13:24:20',0),(65,6,'New Purchase Request','A new purchase request has been submitted for item: Keyboard.',1,'2026-04-21 15:01:11',0),(66,1,'Purchase Request Approved','Purchase request for item \'Keyboard\' has been Approved.',1,'2026-04-21 15:13:12',0),(67,6,'New Purchase Request','A new purchase request has been submitted for item: Battery 2.',1,'2026-04-21 15:14:38',0),(68,12,'Issue Resolved','Your reported issue (#10) has been marked as resolved by Technician technician1.',1,'2026-04-21 23:57:59',0),(69,1,'New Issue Reported','New issue submitted\nUser: AO-Katugasthota\nIssue ID: 17\nType: Hardware\nCategory: other\nService Tag: Dell\nStatus: Pending',1,'2026-04-22 08:46:45',0),(70,1,'New Issue Reported','New issue submitted\nUser: AO-Katugasthota\nIssue ID: 18\nType: Software\nCategory: other\nService Tag: Dell\nStatus: Pending',1,'2026-04-22 08:48:04',0),(71,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 18\nService Tag: Dell\nDescription: OS Error\nStatus: Assigned',1,'2026-04-22 08:48:26',0),(72,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 18\nService Tag: Dell\nDescription: OS Error\nStatus: Assigned',1,'2026-04-22 08:52:14',0),(73,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 17\nService Tag: Dell\nDescription: Motherboard Error\nStatus: Assigned',1,'2026-04-22 15:10:59',0),(74,1,'New Issue Reported','New issue submitted\nUser: kandycity\nIssue ID: 19\nType: Software\nCategory: other\nService Tag: Assembly PC\nStatus: Pending',1,'2026-04-23 10:35:41',0),(75,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 19\nService Tag: Assembly PC\nDescription: OS error\nStatus: Assigned',1,'2026-04-23 11:20:19',0),(76,6,'New Purchase Request','A new purchase request has been submitted for item: Battery.',1,'2026-04-27 15:05:58',0),(77,6,'New Purchase Request','A new purchase request has been submitted for item: Hard Disk.',1,'2026-04-27 15:06:41',0),(78,1,'Purchase Request Approved','Purchase request for item \'Hard Disk\' has been Approved.',1,'2026-04-27 15:08:38',0),(79,1,'New User Registration','New user registered to the system\nUsername: admin2\nPhone: 0777777763\nRole: admin',1,'2026-04-28 08:50:25',0),(81,1,'New User Registration','New user registered to the system\nUsername: AO-Matale\nPhone: 0777777766\nRole: user',1,'2026-04-28 09:37:12',0),(83,6,'New Purchase Request','A new purchase request has been submitted for item: Cupbaord.',1,'2026-04-28 10:09:12',0),(84,6,'New Purchase Request','A new purchase request has been submitted for item: Chair.',1,'2026-04-28 10:09:35',0),(85,6,'New Purchase Request','A new purchase request has been submitted for item: Chair.',1,'2026-04-28 10:09:40',0),(86,6,'New Purchase Request','A new purchase request has been submitted for item: Chair.',1,'2026-04-28 10:20:10',0),(87,6,'New Purchase Request','A new purchase request has been submitted for item: Frame.',1,'2026-04-28 10:30:07',0),(88,1,'Purchase Request Approved','Purchase request for item \'Frame\' has been Approved.',1,'2026-04-28 10:30:40',0),(89,1,'Purchase Request Approved','Purchase request for item \'Chair\' has been Approved.',1,'2026-04-28 10:31:41',0),(90,1,'New Issue Reported','New issue submitted\nUser: ACC(Exp)\nIssue ID: 20\nType: Software\nCategory: other\nService Tag: Dell Optiplex 5040 , S. No: HGC31H2\nStatus: Pending',1,'2026-04-28 10:55:54',0),(91,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 20\nService Tag: Dell Optiplex 5040 , S. No: HGC31H2\nDescription: OS Error\nStatus: Assigned',1,'2026-04-28 10:58:35',0),(92,8,'Issue Resolved','Your reported issue (#20) has been marked as resolved by Technician technician1.',0,'2026-04-28 11:00:30',0),(93,1,'New User Registration','New user registered to the system\nUsername: technician3\nPhone: 0777777722\nRole: technician',1,'2026-04-30 08:56:27',0),(94,1,'New Issue Reported','New issue submitted\nUser: AO-Katugasthota\nIssue ID: 21\nType: Hardware\nCategory: Restart\nService Tag: Dell-Vostro03888, S.No: H2YP7J3\nStatus: Pending',1,'2026-04-30 09:01:15',0),(95,18,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 21\nService Tag: Dell-Vostro03888, S.No: H2YP7J3\nDescription: Restart\nStatus: Assigned',1,'2026-04-30 09:01:51',0),(96,6,'New Purchase Request','A new purchase request has been submitted for item: Chair.',1,'2026-05-05 09:40:07',0),(97,6,'New Purchase Request','A new purchase request has been submitted for item: table.',1,'2026-05-05 10:06:04',0),(98,1,'Purchase Request Approved','Purchase request for item \'Chair\' has been Approved.',1,'2026-05-05 10:10:47',0),(99,1,'Purchase Request Approved','Purchase request for item \'table\' has been Approved.',1,'2026-05-05 10:13:20',0),(100,6,'New Purchase Request','A new purchase request has been submitted for item: mobile.',1,'2026-05-05 10:45:56',0),(101,1,'Purchase Request Approved','Purchase request for item \'mobile\' has been Approved. You can now mark it as Received to update inventory.',1,'2026-05-05 10:46:32',0),(102,1,'New Issue Reported','New issue submitted\nUser: CSC-Karalliyadda\nIssue ID: 22\nType: Hardware\nCategory: other\nService Tag: Acer, S.No:-4CE9111FNS\nStatus: Pending',1,'2026-05-06 12:16:06',0),(103,1,'New Issue Reported','New issue submitted\nUser: kandycity\nIssue ID: 23\nType: Hardware\nCategory: other\nService Tag: hjgjhgghjg\nStatus: Pending',1,'2026-05-06 13:54:23',0),(104,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 23\nService Tag: hjgjhgghjg\nDescription: hgkyhhgkgygjhg\nStatus: Assigned',1,'2026-05-06 13:54:46',0),(105,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician1\nIssue ID: 23\nItems: Monitor (Qty: 1)',1,'2026-05-06 13:55:27',0),(106,5,'Approved Spare Part Item','Admin approved one spare part item.\nRequest ID: 10\nIssue ID: 23\nItem: Monitor\nApproved Quantity: 1\nAction: Please issue this item.',1,'2026-05-06 13:56:35',0),(107,3,'Spare Part Issued','Storekeeper issued one approved spare part.\nRequest ID: 10\nIssue ID: 23\nItem: Monitor\nIssued Quantity: 1',1,'2026-05-06 14:12:50',0),(108,1,'New Issue Reported','New issue submitted\nUser: kandycity\nIssue ID: 24\nType: Hardware\nCategory: other\nService Tag: nmnmn\nStatus: Pending',1,'2026-05-06 14:18:59',0),(109,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 24\nService Tag: nmnmn\nDescription: ,jbjkjbjkhkjhjkhkjh\nStatus: Assigned',1,'2026-05-06 14:19:20',0),(110,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician1\nIssue ID: 24\nItems: Monitor (Qty: 1)',1,'2026-05-06 14:19:58',0),(111,5,'Approved Spare Part Item','Admin approved one spare part item.\nRequest ID: 11\nIssue ID: 24\nItem: Monitor\nApproved Quantity: 1\nAction: Please issue this item.',1,'2026-05-06 14:20:34',0),(112,3,'Spare Part Issued','Storekeeper issued one approved spare part.\nRequest ID: 11\nIssue ID: 24\nItem: Monitor\nIssued Quantity: 1',1,'2026-05-06 14:20:53',0),(113,10,'Issue Resolved','Your reported issue (#24) has been marked as resolved by Technician technician1.',1,'2026-05-06 14:22:23',0),(114,1,'New Issue Reported','New issue submitted\nUser: kandycity\nIssue ID: 25\nType: Software\nCategory: other\nService Tag: jbjhhukuuu\nStatus: Pending',1,'2026-05-06 22:52:12',0),(115,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 25\nService Tag: jbjhhukuuu\nDescription: hnhhhhhhhgtyururubm\nStatus: Assigned',1,'2026-05-06 22:52:29',0),(116,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician1\nIssue ID: 25\nItems: Monitor (Qty: 1)',1,'2026-05-06 22:53:05',0),(117,5,'Approved Spare Part Item','Admin approved one spare part item.\nRequest ID: 12\nIssue ID: 25\nItem: Monitor\nApproved Quantity: 1\nAction: Please issue this item.',1,'2026-05-06 22:53:59',0),(118,3,'Spare Part Issued','Storekeeper issued one approved spare part.\nRequest ID: 12\nIssue ID: 25\nItem: Monitor\nIssued Quantity: 1',1,'2026-05-06 22:54:16',0),(119,10,'Issue Resolved','Your reported issue (#25) has been marked as resolved by Technician technician1.',1,'2026-05-06 22:54:47',0),(120,1,'New Issue Reported','New issue submitted\nUser: kandycity\nIssue ID: 26\nType: Hardware\nCategory: other\nService Tag: nnnnnnn\nStatus: Pending',1,'2026-05-06 22:57:16',0),(121,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 26\nService Tag: nnnnnnn\nDescription: jhjkhjhhhhh\nStatus: Assigned',1,'2026-05-06 22:57:36',0),(122,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician1\nIssue ID: 26\nItems: Monitor (Qty: 1)',1,'2026-05-06 22:58:08',0),(123,1,'New Issue Reported','New issue submitted\nUser: kandycity\nIssue ID: 27\nType: Hardware\nCategory: Restart\nService Tag: Dell\nStatus: Pending',1,'2026-05-07 09:18:31',0),(124,3,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 27\nService Tag: Dell\nDescription: Restart\nStatus: Assigned',1,'2026-05-07 09:19:21',0),(125,1,'New Parts Request Submitted','A technician has requested spare parts.\nTechnician: technician1\nIssue ID: 27\nItems: Monitor (Qty: 1)',1,'2026-05-07 09:20:02',0),(126,5,'Approved Spare Part Item','Admin approved one spare part item.\nRequest ID: 14\nIssue ID: 27\nItem: Monitor\nApproved Quantity: 1\nAction: Please issue this item.',1,'2026-05-07 09:20:27',0),(127,3,'Spare Part Issued','Storekeeper issued one approved spare part.\nRequest ID: 14\nIssue ID: 27\nItem: Monitor\nIssued Quantity: 1',1,'2026-05-07 09:20:55',0),(128,10,'Issue Resolved','Your reported issue (#27) has been marked as resolved by Technician technician1.',1,'2026-05-07 09:21:40',0),(129,6,'New Purchase Request','A new purchase request has been submitted for item: Monitor.',1,'2026-05-07 09:23:22',0),(130,1,'Purchase Request Approved','Purchase request for item \'Monitor\' has been Approved. You can now mark it as Received to update inventory.',1,'2026-05-07 09:24:00',0),(131,1,'New Issue Reported','New issue submitted\nUser: CSC-Karalliyadda\nIssue ID: 28\nType: Hardware\nCategory: other\nService Tag: acer (i5-vertiou), s.no: 20100866992\nStatus: Pending',1,'2026-05-11 12:32:53',0),(132,22,'New Issue Reported','New issue submitted\nUser: CSC-Karalliyadda\nIssue ID: 28\nType: Hardware\nCategory: other\nService Tag: acer (i5-vertiou), s.no: 20100866992\nStatus: Pending',0,'2026-05-11 12:32:53',0),(133,18,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 22\nService Tag: Acer, S.No:-4CE9111FNS\nDescription: Switch and casing\nStatus: Assigned',0,'2026-05-11 12:42:42',0),(134,18,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 28\nService Tag: acer (i5-vertiou), s.no: 20100866992\nDescription: Blue screen error\nStatus: Assigned',0,'2026-05-11 12:50:51',0),(135,1,'New Issue Reported','New issue submitted\nUser: AO-Galagedara\nIssue ID: 29\nType: Hardware\nCategory: other\nService Tag: EGS, S.NO: EGS/200/1600/0601(PC)\nStatus: Pending',1,'2026-05-20 10:10:45',0),(136,22,'New Issue Reported','New issue submitted\nUser: AO-Galagedara\nIssue ID: 29\nType: Hardware\nCategory: other\nService Tag: EGS, S.NO: EGS/200/1600/0601(PC)\nStatus: Pending',0,'2026-05-20 10:10:45',0),(137,1,'New Issue Reported','New issue submitted\nUser: AO-Galagedara\nIssue ID: 30\nType: Hardware\nCategory: other\nService Tag: Assembly PC\nStatus: Pending',1,'2026-06-02 13:30:10',0),(138,22,'New Issue Reported','New issue submitted\nUser: AO-Galagedara\nIssue ID: 30\nType: Hardware\nCategory: other\nService Tag: Assembly PC\nStatus: Pending',0,'2026-06-02 13:30:10',0),(139,1,'New Issue Reported','New issue submitted\nUser: P&D\nIssue ID: 31\nType: Software\nCategory: other\nService Tag: Assembly PC\nStatus: Pending',1,'2026-06-02 13:34:45',0),(140,22,'New Issue Reported','New issue submitted\nUser: P&D\nIssue ID: 31\nType: Software\nCategory: other\nService Tag: Assembly PC\nStatus: Pending',0,'2026-06-02 13:34:45',0),(141,1,'New Issue Reported','New issue submitted\nUser: P&D\nIssue ID: 32\nType: Hardware\nCategory: No power\nService Tag: Assembly PC\nStatus: Pending',1,'2026-06-02 13:36:07',0),(142,22,'New Issue Reported','New issue submitted\nUser: P&D\nIssue ID: 32\nType: Hardware\nCategory: No power\nService Tag: Assembly PC\nStatus: Pending',0,'2026-06-02 13:36:07',0),(143,1,'New Issue Reported','New issue submitted\nUser: CSC-Madolkale\nIssue ID: 33\nType: Software\nCategory: other\nService Tag: HP i5, serial no: 4CE549DR7M\nStatus: Pending',1,'2026-06-02 13:38:38',0),(144,22,'New Issue Reported','New issue submitted\nUser: CSC-Madolkale\nIssue ID: 33\nType: Software\nCategory: other\nService Tag: HP i5, serial no: 4CE549DR7M\nStatus: Pending',0,'2026-06-02 13:38:38',0),(145,1,'New Issue Reported','New issue submitted\nUser: CSC-Madolkale\nIssue ID: 34\nType: Software\nCategory: other\nService Tag: HP i5, serial no: 4CE549BYC7\nStatus: Pending',1,'2026-06-02 13:40:15',0),(146,22,'New Issue Reported','New issue submitted\nUser: CSC-Madolkale\nIssue ID: 34\nType: Software\nCategory: other\nService Tag: HP i5, serial no: 4CE549BYC7\nStatus: Pending',0,'2026-06-02 13:40:15',0),(147,18,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 34\nService Tag: HP i5, serial no: 4CE549BYC7\nDescription: OS Updating Error and EDL System Error\nStatus: Assigned',0,'2026-06-02 13:51:11',0),(148,18,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 33\nService Tag: HP i5, serial no: 4CE549DR7M\nDescription: OS Error and EDL system error\nStatus: Assigned',0,'2026-06-02 13:51:15',0),(149,18,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 32\nService Tag: Assembly PC\nDescription: No power\nStatus: Assigned',0,'2026-06-02 13:51:18',0),(150,18,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 31\nService Tag: Assembly PC\nDescription: OS Error\nStatus: Assigned',0,'2026-06-02 13:51:21',0),(151,18,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 30\nService Tag: Assembly PC\nDescription: RAM Error(Beep Sound)\nStatus: Assigned',0,'2026-06-02 13:51:37',0),(152,18,'New Issue Assigned','You have been assigned a new issue\nIssue ID: 29\nService Tag: EGS, S.NO: EGS/200/1600/0601(PC)\nDescription: Power supply error\nStatus: Assigned',0,'2026-06-02 13:51:40',0);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parts_request_items`
--

DROP TABLE IF EXISTS `parts_request_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parts_request_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` int NOT NULL,
  `item_id` int NOT NULL,
  `quantity_requested` int NOT NULL,
  `quantity_approved` int DEFAULT NULL,
  `quantity_issued` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `item_status` enum('Pending','Approved','Rejected','Supplied') NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id`),
  KEY `fk_pri_request` (`request_id`),
  KEY `fk_pri_item` (`item_id`),
  CONSTRAINT `fk_pri_item` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pri_request` FOREIGN KEY (`request_id`) REFERENCES `parts_requests` (`request_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parts_request_items`
--

LOCK TABLES `parts_request_items` WRITE;
/*!40000 ALTER TABLE `parts_request_items` DISABLE KEYS */;
INSERT INTO `parts_request_items` VALUES (1,1,59,1,0,0,'2026-04-20 03:34:33','Rejected'),(2,2,59,1,0,0,'2026-04-20 04:01:58','Rejected'),(4,4,60,1,0,0,'2026-04-20 05:41:36','Rejected'),(5,4,61,1,0,0,'2026-04-20 05:41:36','Rejected'),(6,5,61,1,0,0,'2026-04-20 05:58:28','Rejected'),(7,5,60,1,0,0,'2026-04-20 05:58:28','Rejected'),(8,6,60,1,0,0,'2026-04-20 06:19:59','Rejected'),(9,6,61,1,0,0,'2026-04-20 06:19:59','Rejected'),(10,7,62,1,1,1,'2026-04-20 06:57:29','Supplied'),(11,8,60,1,1,1,'2026-04-20 07:33:16','Supplied'),(12,9,63,2,2,2,'2026-04-20 07:40:46','Supplied');
/*!40000 ALTER TABLE `parts_request_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parts_requests`
--

DROP TABLE IF EXISTS `parts_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parts_requests` (
  `request_id` int NOT NULL AUTO_INCREMENT,
  `issue_id` int NOT NULL,
  `technician_id` int NOT NULL,
  `admin_id` int DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected','Supplied') DEFAULT 'Pending',
  `approval_date` datetime DEFAULT NULL,
  `admin_note` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `admin_archived` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`request_id`),
  KEY `fk_parts_requests_issue` (`issue_id`),
  KEY `fk_parts_requests_technician` (`technician_id`),
  KEY `fk_parts_requests_admin` (`admin_id`),
  CONSTRAINT `fk_parts_requests_admin` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_parts_requests_issue` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_parts_requests_technician` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parts_requests`
--

LOCK TABLES `parts_requests` WRITE;
/*!40000 ALTER TABLE `parts_requests` DISABLE KEYS */;
INSERT INTO `parts_requests` VALUES (1,4,4,1,'Rejected','2026-04-20 09:05:31',NULL,'2026-04-20 03:34:33',0),(2,2,4,1,'Rejected','2026-04-20 09:33:25',NULL,'2026-04-20 04:01:58',0),(3,5,3,1,'Rejected','2026-04-20 09:50:40',NULL,'2026-04-20 04:20:15',0),(4,6,4,1,'Rejected','2026-04-20 11:12:08',NULL,'2026-04-20 05:41:36',0),(5,2,4,1,'Rejected','2026-04-20 11:28:52',NULL,'2026-04-20 05:58:28',0),(6,2,4,1,'Rejected','2026-04-20 11:50:42',NULL,'2026-04-20 06:19:59',0),(7,9,4,NULL,'Supplied',NULL,NULL,'2026-04-20 06:57:29',0),(8,13,3,NULL,'Supplied',NULL,NULL,'2026-04-20 07:33:16',0),(9,14,4,NULL,'Supplied',NULL,NULL,'2026-04-20 07:40:46',0);
/*!40000 ALTER TABLE `parts_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_requests`
--

DROP TABLE IF EXISTS `purchase_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_requests` (
  `purchase_request_id` int NOT NULL AUTO_INCREMENT,
  `admin_id` int NOT NULL,
  `item_id` int DEFAULT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `request_type` enum('Inventory','Manual') DEFAULT 'Manual',
  `justification` text NOT NULL,
  `letter_content` text NOT NULL,
  `status` enum('Pending','Approved','Rejected','Received') DEFAULT 'Pending',
  `unit_head_remarks` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`purchase_request_id`),
  KEY `fk_purchase_admin` (`admin_id`),
  CONSTRAINT `fk_purchase_admin` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_requests`
--

LOCK TABLES `purchase_requests` WRITE;
/*!40000 ALTER TABLE `purchase_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `action` varchar(255) NOT NULL,
  `details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
INSERT INTO `system_logs` VALUES (1,1,'Test Activity','Initial test activity insertion','2026-05-20 04:32:50'),(2,1,'Database Backup Failed','Attempt to backup database failed','2026-05-20 04:36:10'),(3,1,'User Logout','User logged out','2026-05-20 04:37:26'),(4,21,'User Login','User successfully logged in as user','2026-05-20 04:37:42'),(5,21,'User Logout','User logged out','2026-05-20 04:38:07'),(6,1,'User Login','User successfully logged in as admin','2026-05-20 04:38:20'),(7,1,'User Logout','User logged out','2026-05-20 04:38:43'),(8,23,'User Login','User successfully logged in as user','2026-05-20 04:38:59'),(9,23,'User Logout','User logged out','2026-05-20 04:40:51'),(10,1,'Failed Login Attempt','Invalid password entered','2026-05-20 04:41:01'),(11,1,'User Login','User successfully logged in as admin','2026-05-20 04:41:10'),(12,1,'Database Backup','Manual backup triggered: backup_2026-05-20_09-05-10.sql','2026-05-20 07:05:11'),(13,1,'Database Backup','Manual backup triggered: backup_2026-05-20_09-07-21.sql','2026-05-20 07:07:21'),(14,1,'User Login','User successfully logged in as admin','2026-05-20 07:33:54'),(15,1,'User Login','User successfully logged in as admin','2026-05-21 03:34:19'),(16,0,'Backup Failed','PHP ZipArchive extension is disabled. Cannot compress backup.','2026-05-25 04:47:48'),(17,0,'Database Backup','Database backup completed. File: hms_backup_2026_05_25_100536.zip (9.83 KB). Google Drives: [Drive 1: Skipped (Not Configured) (Deleted 0), Drive 2: Skipped (Not Configured) (Deleted 0)]. Local Deleted: 0 files.','2026-05-25 04:48:36'),(18,1,'Failed Login Attempt','Invalid password entered','2026-05-25 05:03:35'),(19,1,'User Login','User successfully logged in as admin','2026-05-25 05:03:50'),(20,0,'Database Backup','Database backup completed. File: hms_backup_2026_05_25_110537.zip (9.96 KB). Google Drives: [Drive 1: Skipped (Not Configured) (Deleted 0), Drive 2: Skipped (Not Configured) (Deleted 0)]. Local Deleted: 0 files.','2026-05-25 06:00:38'),(21,0,'Database Backup','Database backup completed. File: hms_backup_2026_05_25_110516.zip (9.98 KB). Google Drives: [Drive 1: Skipped (Not Configured) (Deleted 0), Drive 2: Skipped (Not Configured) (Deleted 0)]. Local Deleted: 0 files.','2026-05-25 06:23:17'),(22,0,'Database Backup','Database backup completed. File: hms_backup_2026_05_25_120545.zip (10 KB). Google Drives: [Drive 1: Failed to Authenticate (Deleted 0), Drive 2: Skipped (Not Configured) (Deleted 0)]. Local Deleted: 0 files.','2026-05-25 06:39:47'),(23,1,'User Login','User successfully logged in as admin','2026-05-25 07:05:47'),(24,1,'Failed Login Attempt','Invalid password entered','2026-05-29 03:16:26'),(25,1,'Failed Login Attempt','Invalid password entered','2026-05-29 03:16:34'),(26,1,'User Login','User successfully logged in as admin','2026-05-29 03:16:49'),(27,1,'User Login','User successfully logged in as admin','2026-05-29 04:46:36'),(28,1,'User Logout','User logged out','2026-05-29 05:00:27'),(29,3,'User Login','User successfully logged in as technician','2026-05-29 05:00:41'),(30,3,'User Logout','User logged out','2026-05-29 05:01:11'),(31,10,'User Login','User successfully logged in as user','2026-05-29 05:01:18'),(32,10,'User Logout','User logged out','2026-05-29 05:03:21'),(33,5,'User Login','User successfully logged in as storekeeper','2026-05-29 05:03:26'),(34,5,'User Logout','User logged out','2026-05-29 05:03:45'),(35,1,'User Login','User successfully logged in as admin','2026-06-01 04:07:26'),(36,1,'User Login','User successfully logged in as admin','2026-06-02 03:28:06'),(37,1,'User Login','User successfully logged in as admin','2026-06-02 07:58:08'),(38,1,'User Logout','User logged out','2026-06-02 07:59:02'),(39,23,'User Login','User successfully logged in as user','2026-06-02 07:59:12'),(40,23,'User Logout','User logged out','2026-06-02 08:00:27'),(41,24,'User Login','User successfully logged in as user','2026-06-02 08:01:25'),(42,24,'User Logout','User logged out','2026-06-02 08:04:59'),(43,24,'User Login','User successfully logged in as user','2026-06-02 08:05:23'),(44,24,'User Logout','User logged out','2026-06-02 08:06:10'),(45,25,'User Login','User successfully logged in as user','2026-06-02 08:07:07'),(46,25,'User Logout','User logged out','2026-06-02 08:10:27'),(47,15,'User Login','User successfully logged in as user','2026-06-02 08:10:36'),(48,15,'User Logout','User logged out','2026-06-02 08:16:08'),(49,22,'Failed Login Attempt','Invalid password entered','2026-06-02 08:16:17'),(50,22,'User Login','User successfully logged in as admin','2026-06-02 08:16:28'),(51,22,'User Logout','User logged out','2026-06-02 08:16:46'),(52,3,'User Login','User successfully logged in as technician','2026-06-02 08:16:52'),(53,3,'User Logout','User logged out','2026-06-02 08:20:00'),(54,5,'User Login','User successfully logged in as storekeeper','2026-06-02 08:20:41'),(55,5,'User Logout','User logged out','2026-06-02 08:20:50'),(56,1,'User Login','User successfully logged in as admin','2026-06-02 08:21:00'),(57,1,'Assign Issue','Assigned issue ID 34 to technician ID 18','2026-06-02 08:21:11'),(58,1,'Assign Issue','Assigned issue ID 33 to technician ID 18','2026-06-02 08:21:15'),(59,1,'Assign Issue','Assigned issue ID 32 to technician ID 18','2026-06-02 08:21:18'),(60,1,'Assign Issue','Assigned issue ID 31 to technician ID 18','2026-06-02 08:21:22'),(61,1,'Assign Issue','Assigned issue ID 30 to technician ID 18','2026-06-02 08:21:37'),(62,1,'Assign Issue','Assigned issue ID 29 to technician ID 18','2026-06-02 08:21:40'),(63,1,'User Logout','User logged out','2026-06-02 08:22:27'),(64,1,'User Login','User successfully logged in as admin','2026-06-02 09:46:52'),(65,1,'User Login','User successfully logged in as admin','2026-06-02 09:50:18'),(66,0,'Database Backup','Database backup completed. File: hms_backup_2026_06_02_150658.zip (11.14 KB). Google Drives: [Drive 1: Success (ID: 1VGB8M9KZPdAGQx71ZP-d7kEDQYydyTtW) (Deleted 0), Drive 2: Skipped (Not Configured) (Deleted 0)]. Local Deleted: 0 files.','2026-06-02 09:56:05'),(67,1,'User Login','User successfully logged in as admin','2026-06-05 03:27:15'),(68,0,'Database Backup','Database backup completed. File: hms_backup_2026_06_05_080625.zip (11.22 KB). Google Drives: [Drive 1: Success (ID: 10bSRATZvlWEAzxwzQgPC0v649Oioeusq) (Deleted 0), Drive 2: Skipped (Not Configured) (Deleted 0)]. Local Deleted: 0 files.','2026-06-05 03:27:32'),(69,1,'Failed Login Attempt','Invalid password entered','2026-06-08 09:26:04'),(70,1,'Failed Login Attempt','Invalid password entered','2026-06-08 09:26:20'),(71,1,'User Login','User successfully logged in as admin','2026-06-08 09:26:32'),(72,1,'Update Inventory Item','Updated details of item \'Battery\' (ID 63)','2026-06-08 09:33:07'),(73,1,'Update Inventory Item','Updated details of item \'Cat 6 Network Cable\' (ID 57)','2026-06-08 09:33:41'),(74,1,'Update Inventory Item','Updated details of item \'CAT6 Network Cable Box\' (ID 20)','2026-06-08 09:34:43'),(75,1,'Update Inventory Item','Updated details of item \'CMOS Battery\' (ID 29)','2026-06-08 09:35:21'),(76,1,'Update Inventory Item','Updated details of item \'Frame ATX Casing\' (ID 65)','2026-06-08 09:38:19'),(77,1,'Update Inventory Item','Updated details of item \'Hard Disk -SSD\' (ID 58)','2026-06-08 09:45:35'),(78,1,'Update Inventory Item','Updated details of item \'Keyboard\' (ID 49)','2026-06-08 09:46:16'),(79,1,'User Login','User successfully logged in as admin','2026-06-09 03:30:36'),(80,1,'Update Inventory Item','Updated details of item \'Network Switch\' (ID 40)','2026-06-09 03:32:54'),(81,1,'Delete Inventory Item','Deleted inventory item \'Unmanaged Network Switch\' (ID 26)','2026-06-09 03:33:10'),(82,1,'Update Inventory Item','Updated details of item \'Network Switch\' (ID 39)','2026-06-09 03:34:07'),(83,1,'Delete Inventory Item','Deleted inventory item \'Unmanaged Network Switch\' (ID 27)','2026-06-09 03:34:17'),(84,1,'Delete Inventory Item','Deleted inventory item \'USB 3.0 HUB\' (ID 25)','2026-06-09 03:35:20'),(85,1,'Delete Inventory Item','Deleted inventory item \'UPS Battery\' (ID 10)','2026-06-09 03:36:05'),(86,1,'Update Inventory Item','Updated details of item \'Frame ATX Casing\' (ID 65)','2026-06-09 03:42:59'),(87,0,'Database Backup','Database backup completed. File: hms_backup_2026_06_09_090629.zip (11.53 KB). Google Drives: [Drive 1: Success (ID: 1dACtQuN_m8IFpHLw3R0iV715XSKPPd0N) (Deleted 0), Drive 2: Skipped (Not Configured) (Deleted 0)]. Local Deleted: 0 files.','2026-06-09 03:46:49'),(88,1,'User Login','User successfully logged in as admin','2026-06-10 05:23:21'),(89,1,'User Login','User successfully logged in as admin','2026-06-10 05:24:46'),(90,1,'User Logout','User logged out','2026-06-10 05:47:15'),(91,10,'User Login','User successfully logged in as user','2026-06-10 05:47:32'),(92,10,'User Logout','User logged out','2026-06-10 05:47:45'),(93,3,'User Login','User successfully logged in as technician','2026-06-10 05:48:01'),(94,1,'User Login','User successfully logged in as admin','2026-06-10 05:49:11'),(95,3,'User Logout','User logged out','2026-06-10 05:49:23'),(96,5,'User Login','User successfully logged in as storekeeper','2026-06-10 05:49:34'),(97,5,'User Logout','User logged out','2026-06-10 05:52:07'),(98,6,'User Login','User successfully logged in as unithead','2026-06-10 05:52:20'),(99,6,'User Logout','User logged out','2026-06-10 05:54:07'),(100,1,'User Login','User successfully logged in as admin','2026-06-11 04:38:00'),(101,1,'User Login','User successfully logged in as admin','2026-06-11 04:49:25'),(102,1,'User Logout','User logged out','2026-06-11 04:50:11'),(103,25,'User Login','User successfully logged in as user','2026-06-11 04:50:27'),(104,25,'User Logout','User logged out','2026-06-11 04:50:57'),(105,24,'User Login','User successfully logged in as user','2026-06-11 04:52:32'),(106,15,'Failed Login Attempt','Invalid password entered','2026-06-11 04:53:40'),(107,15,'User Login','User successfully logged in as user','2026-06-11 04:53:51'),(108,1,'User Login','User successfully logged in as admin','2026-06-22 10:30:51');
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES ('service_alert','','2026-05-05 08:48:36'),('service_alert_enabled','1','2026-05-05 08:51:39');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user','technician','storekeeper','unithead') NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Sanjeewa Herath','admin1','0718216568','$2y$10$UuJx.x800sH8Ed.FkGwMtOW/tSykuXhbItEGvjtYwR//teP0grYEO','admin',NULL,'active','2026-04-07 09:11:19','2026-05-11 06:21:11'),(2,'Waru','DGM','0765590981','1234','user',NULL,'active','2026-04-07 09:46:50','2026-05-11 12:54:07'),(3,'Charitha','technician1','0777777775','$2y$10$derOzLDfuruHgFIMb58uRuO3tWn74cDtjcpYvf57BaD2YM1e7W2PW','technician',NULL,'active','2026-04-07 09:53:09','2026-04-28 05:29:04'),(4,'Kasun','technician2','0777777743','1234','technician',NULL,'active','2026-04-07 09:53:39','2026-04-28 04:23:34'),(5,'Ajith','storekeeper','0777777744','$2y$10$T3cf069PsW44iiDFirUGhuc8CJs2IhfjzCQGrePe1i1DCPlppRoTi','storekeeper',NULL,'active','2026-04-07 09:54:22','2026-05-05 04:33:10'),(6,'Maneesha','unithead','0763897819','$2y$10$YMRSUrY883/SL778xmth6eBa5IwZwcav2Topn98YPc8704U2w0/3O','unithead',NULL,'active','2026-04-07 09:55:01','2026-04-30 04:01:47'),(7,'Umanda','DM','0777777777','1234','user',NULL,'active','2026-04-10 05:16:31','2026-04-28 04:24:09'),(8,'Amali','ACC(Exp)','0777777772','$2y$10$pZXO4kEVA4Leg4.lrVUbVu229mbQLh2B3J2./UA2JdJU0/unelTI2','user',NULL,'active','2026-04-20 04:06:09','2026-04-28 05:20:45'),(9,'Kamal','Energy','0777777773','1234','user',NULL,'active','2026-04-20 04:25:36','2026-04-28 04:24:32'),(10,'manee','kandycity','0777777776','$2y$10$tOmwqnXN0kQx.LOvTo0Z6e9Hbi9dfES.Xfq.Ze4BfAQBvAwIY/pou','user',NULL,'active','2026-04-20 05:46:18','2026-04-28 05:21:45'),(11,' Chamu','CSC-Kandysouth','0777777778','1234','user',NULL,'active','2026-04-20 06:52:28','2026-05-06 06:47:24'),(12,'Amaya','AO-Dambulla','0777777779','1234','user',NULL,'active','2026-04-20 07:12:22','2026-04-28 04:25:02'),(13,'Ama','AO-Katugasthota','0777777701','$2y$10$62mRL73k.h69U2pHwBvdHOFw.IdQJ8dRRYZe9Z.R9NXq2HTdY6WCq','user',NULL,'active','2026-04-20 07:16:29','2026-04-28 05:19:32'),(14,'lak','CE(Cons)','0777777702','1234','user',NULL,'active','2026-04-20 07:26:22','2026-04-28 04:25:24'),(15,'shiro','Acc(Rev)','0777777703','$2y$10$XI/T3zDUGDEUnSU43PZkbe6bJGq7EwsGiLhgCkLO49JBeS0SRYXd.','user',NULL,'active','2026-04-20 07:35:05','2026-06-02 08:10:36'),(17,'laksh','AO-Matale','0777777766','1234','user',NULL,'active','2026-04-28 04:07:12','2026-04-28 04:25:52'),(18,'laks','technician3','0777777722','$2y$10$ag0S5QGfMEKiV/8vL5dqne1HFVzQMr9EAkClKNFB2B4X5Y7hGbMsK','technician',NULL,'active','2026-04-30 03:26:27','2026-04-30 03:26:27'),(21,'vima','CSC-Karalliyadda','0777777798','$2y$10$AjFbAilvPZWD0WoC1Xo9J.rkK42ul/SOgZ.luapWtvmpu.1ei8LHS','user',NULL,'active','2026-05-06 06:43:28','2026-05-06 06:43:28'),(22,'Uthpala Gunawardana','admin2','0714481018','$2y$10$kb8aHXY9ykj6ovoJC172deAlLlAHaps1xt7Q2sYc/P7ytib11oovS','admin',NULL,'active','2026-05-11 06:19:44','2026-05-11 06:20:51'),(23,'ssssss','AO-Galagedara','076 389 7810','$2y$10$TEw1zDdMeamliQIDwas1fueLCzXRDCXw3lRlmtvdZlX/SUnyDVaDu','user',NULL,'active','2026-05-11 06:58:04','2026-05-11 06:58:04'),(24,'kjhjkhkjh','P&D','0777777795','$2y$10$ObQdtlZGnxuF5y1SzSPFrudg8oC8LgQTN6vN6b6/Epowu3qeWz7P6','user',NULL,'active','2026-06-02 08:01:11','2026-06-02 08:01:11'),(25,'UIYUIYIUIY','CSC-Madolkale','0777777789','$2y$10$qBdy7QEG2U4Pf7.hScNuIOW8l9iKjGlPOkVtpbx3Fx/mUnL6E.wgK','user',NULL,'active','2026-06-02 08:06:56','2026-06-02 08:06:56');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 16:01:10
